let count = 0;

const number = document.getElementById('number');
const btnMinus = document.getElementById('minus');
const btnPlus = document.getElementById('plus');
const btnReset = document.getElementById('reset');


function changeColor() {
    if (count > 0) {
        number.style.color = "green";
    } else if (count < 0) {
        number.style.color = "red";
    } else {
        number.style.color = "black";
    }
}

btnPlus.onclick = function() {
    count = count + 1;
    number.textContent = count;
    changeColor();
}

btnMinus.onclick = function() {
    count = count - 1;
    number.textContent = count;
    changeColor();
}

btnReset.onclick = function() {
    count = 0;
    number.textContent = count;
    changeColor();
}